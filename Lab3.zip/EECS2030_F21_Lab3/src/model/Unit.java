package model;

public class Unit {

	private String roomName;
	private int width;
	private int length;
	private double widthM;
	private double lengthM;
	private int counter;
	private int area;
	private int count;

	public Unit(String roomName, int width, int length) {
		this.roomName = roomName;
		this.width = width;
		this.length = length;
		this.widthM = 0.0;
		this.lengthM = 0.0;
		this.counter = 1;
		this.count = 0;
		this.area = width * length;
	}

	public void toogleMeasurement() {
		if(this.count == 0) {
			this.widthM = this.width * 0.3048;
			this.lengthM = this.length * 0.3048;
			this.count++;
		}
		this.counter++;
	}

	public String getRoomName() {
		return this.roomName;
	}

	public int getWidth() {
		return this.width;
	}

	public int getLength() {
		return this.length;
	}

	public boolean equals(Object obj) {
		if(this == obj) { 
			return true; 
		}
		if(obj == null || this.getClass() != obj.getClass()) {
			return false; 
		}
		Unit other = (Unit) obj;
		return this.roomName.equals(other.roomName) && this.area == other.area;
	}

	public String toString() {
		String s;
		if(this.counter % 2 == 0) {
			s = String.format("A unit of %.2f square meters (%.2f m wide and %.2f m long) functioning as %s", this.widthM * this.lengthM, this.widthM, this.lengthM, this.roomName);
		}else {
			s = String.format("A unit of %d square feet (%d' wide and %d' long) functioning as %s", this.length * this.width, this.width, this.length, this.roomName);
		}
		return s;
	}
}
