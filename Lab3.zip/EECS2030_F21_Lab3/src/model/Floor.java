package model;

public class Floor {

	private int capacity;
	private int totCap;
	private int flag;
	private Unit[] newUnit;
	private int nou;
	private int utilSpace;

	public Floor(int capacity) {
		this.capacity = capacity;
		this.totCap = capacity;
		this.flag = 0;
		this.newUnit = new Unit[20];
		this.utilSpace = 0;
		this.nou = 0;
	}

	public int getCapacity() {
		return this.totCap;
	}

	public void addUnit(String name, int wid, int len) throws InsufficientFloorSpaceException{
		if(this.capacity >= wid * len) {
			Unit U1 = new Unit(name, wid, len);
			this.newUnit[this.nou] = U1;
			this.capacity = this.capacity - wid * len;
			this.utilSpace = this.utilSpace + wid * len;
			this.nou++;
		}
		else {
			throw new InsufficientFloorSpaceException();
		}
		this.flag = -1;
	}

	public int getNOU() {
		return this.nou;
	}

	public String getName(int i) {
		return this.newUnit[i].getRoomName();
	}

	public int getLen(int i) {
		return this.newUnit[i].getLength();
	}

	public int getWid(int i) {
		return this.newUnit[i].getWidth();
	}

	public boolean equals (Object obj) {
		if(this == obj) { 
			return true; 
		}
		if(obj == null || this.getClass() != obj.getClass()) {
			return false; 
		}
		Floor other = (Floor) obj;
		if(this.capacity == other.capacity) {
			return true;
		}
		boolean equal = false;
		if(this.nou == other.nou) {
			equal = false;
			for(int i = 0; equal && i < this.nou; i ++) {
				equal = this.newUnit[i].equals(other.newUnit[i]);
			} 
		} 
		return equal;
	}

	public String toString() {
		String s;
		if(this.flag == 0)
			s = String.format("Floor's utilized space is 0 sq ft (%d sq ft remaining): []", this.capacity);
		else {
			StringBuilder sb = new StringBuilder();
			sb.append("Floor's utilized space is " + this.utilSpace + " sq ft (" + this.capacity + " sq ft remaining): [");
			for(int i = 0; i < this.nou; i++) {
				sb.append(this.newUnit[i].getRoomName().toString() + ": " + (this.newUnit[i].getWidth() * this.newUnit[i].getLength()) + " sq ft (" + this.newUnit[i].getWidth() + "' by " + this.newUnit[i].getLength()+"')");
				if(i < this.nou-1) {
					sb.append(", ");
				}
			}
			sb.append("]");
			s = sb.toString();
		}
		return s;
	}
}
