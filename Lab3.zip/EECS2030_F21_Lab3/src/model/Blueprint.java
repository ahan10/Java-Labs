package model;

public class Blueprint {

	private int totalNOF;
	private Floor[] floorPlan;
	private int nof;

	public Blueprint(int nof) {
		this.totalNOF = nof;
		this.nof = 0;
		this.floorPlan = new Floor[nof];
	}

	public Blueprint(Blueprint bp1) {
		this(bp1.totalNOF);
		for(int i = 0; i < bp1.nof; i ++) {
			Floor nf = new Floor(bp1.floorPlan[i].getCapacity());
			for(int j = 0; j < bp1.floorPlan[i].getNOU(); j++) {
				try {
					nf.addUnit(bp1.floorPlan[i].getName(j).toString(), bp1.floorPlan[i].getWid(j), bp1.floorPlan[i].getLen(j));
				} catch(InsufficientFloorSpaceException e) {
					System.out.println("InsufficientFloorSpaceException");
				}
				
			}
			this.addFloorPlan(nf);
		}
	}

	public void addFloorPlan(Floor f1) {
		this.floorPlan[this.nof] = f1;
		this.nof++;
	}

	public Floor[] getFloors() {
		Floor[] fp = new Floor[this.nof];
		for(int i = 0; i < this.nof; i ++) {
			Floor nf = new Floor(this.floorPlan[i].getCapacity());
			for(int j = 0; j < this.floorPlan[i].getNOU(); j++) {
				try {
					nf.addUnit(this.floorPlan[i].getName(j).toString(), this.floorPlan[i].getWid(j), this.floorPlan[i].getLen(j));
				} catch(InsufficientFloorSpaceException e) {
					System.out.println("InsufficientFloorSpaceException");
				}
			}
			fp[i] = nf;
		}
		return fp;
	}

	public boolean equals (Object obj) {
		if(this == obj) { return true; }
		if(obj == null || this.getClass() != obj.getClass()) {
			return false; }
		Blueprint other = (Blueprint) obj;
		boolean equal = false;
		if(this.nof == other.nof) {
			equal = true;
			for(int i = 0; equal && i < this.nof; i ++) {
				equal = this.floorPlan[i].equals(other.floorPlan[i]); 
			} 
		} 
		return equal;
	}

	public String toString() {
		String s;
		s = String.format("%.1f percents of building blueprint completed (%d out of %d floors)", ((double) this.nof/ (double) this.totalNOF) * 100 , this.nof, this.totalNOF);
		return s;
	}
}
