package model;

public class InsufficientFloorSpaceException extends Exception {

}
