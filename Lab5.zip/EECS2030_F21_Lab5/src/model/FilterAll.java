package model;

public class FilterAll extends SeqEvaluator {

	protected String res;
	protected String finStr;
	
	public FilterAll(int i) {
		super(i);
		this.res = "";
		this.finStr = "";
	}
	
	public void addOperation(String op, int[] seq1, int[] seq2) throws IllegalOperationException{
		if(op != "op:projection" && op != "op:sumsOfPrefixes" && op !="op:occursWithin") {
			throw new IllegalOperationException();
		}else if(op.equals("op:projection") || op.equals("op:sumsOfPrefixes") || op.equals("op:occursWithin") && (this.nos < this.MAX_OP)) {
			OccursWithin occurs;
			
			if(op.equals("op:projection")) {
				this.noe++;
			}
			
			if(op.equals("op:sumsOfPrefixes")) {
				this.noe++;
			}
			
			if( op.equals("op:occursWithin")) {
				occurs = new OccursWithin(seq1, seq2);
				if(occurs.getBool()) {
					this.res = "true";
				}else {
					this.res = "_";
				}
			}
			
			this.seq[this.nos] = this.res;
			this.nos++;
			
			String temp = "Filter result is: ";
			
			
			for(int i = 0; i < this.nos; i++) {
				temp += this.seq[i];
				
				if(i < this.nos - 1) {
					 temp += ", ";
				}
				
			}
			
			this.finStr = temp;
			
			if(this.noe > 0) {
				this.finStr = String.format("Filter cannot be evaluated due to %d incompatile operations.", this.noe);
			}
			
		}
		
	}
	
	public String toString() {
		return this.finStr;
	}
	
}
