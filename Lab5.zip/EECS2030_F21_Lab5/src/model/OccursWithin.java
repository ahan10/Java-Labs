package model;

public class OccursWithin extends BinarySeqOperation {

	protected int[] seq1;
	protected int[] seq2;
	protected boolean occur;
	
	public OccursWithin(int[] seq1a, int[] seq2) {
		this.seq1 = seq1a;
		this.seq2 = seq2;
		this.occurs(this.seq1, this.seq2);
	}

	public boolean occurs(int[] seq1, int[] seq2) {
		
		int[] largerArray = null;
		int[] smallerArray = null;
		boolean b = false;
		
		if(seq1.length > seq2.length) {
			largerArray = seq1;
			smallerArray = seq2;
		}else {
			largerArray = seq2;
			smallerArray = seq1;
		}

		for(int i = 0; i < largerArray.length; i++) {
			if(largerArray[i] == smallerArray[0]) {
				b = true;
				for (int j = 0, k = i; j < smallerArray.length; j++, k++) {
					if (smallerArray[j] != largerArray[k]) {
						b = false;
						break;
					}
				}
				if(b) {
					break;
				}
			}
		}
		
		this.occur = b;
		return b;
	}
	
	public boolean getBool() {
		return this.occur;
	}
	
	public String toString() {
		String s;
		
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0; i<this.seq1.length;i++) {
			sb.append(this.seq1[i]);
			if(i<this.seq1.length-1) {
				sb.append(", ");
			}
		}
		sb.append("]");
		String seqa = sb.toString();
		
		StringBuilder sb1 = new StringBuilder();
		sb1.append("[");
		for(int i = 0; i<this.seq2.length;i++) {
			sb1.append(this.seq2[i]);
			if(i<this.seq2.length-1) {
				sb1.append(", ");
			}
		}
		sb1.append("]");
		String seqb = sb1.toString();
		
		if(this.occurs(this.seq1, this.seq2)) {
			s = String.format("%s occurs within %s", seqa, seqb);
		}else {
			s = String.format("%s does not occur within %s", seqa, seqb);
		}
		
		return s;
	}
	
}
