package model;
public class Projection extends BinarySeqOperation {

	protected int[] seq1;
	protected int[] seq2;
	protected String res;
	protected int nod;
	
	public Projection(int[] seq1a, int[] seq2) {
		this.seq1 = seq1a;
		this.seq2 = seq2;
		this.projects(this.seq1, this.seq2);
	}

	public void projects(int[] seq1, int[] seq2) {

		int[] x = null; 
		int[] y = null;
		int[] z = null;
		
		if(this.seq1.length >= this.seq2.length) {
			z = new int[this.seq1.length];
		}else if(this.seq2.length > this.seq1.length) {
			z = new int[this.seq2.length];
		}
		
		y = this.seq1;
		x = this.seq2;
		
		for(int i = 0; i < x.length; i++) {
			for(int j = 0; j < y.length; j++) {
				if(x[i] == y[j]) {
					z[this.nod] = y[j];
					this.nod++;
					break;
				}
			}
		}
		
		StringBuilder sb2 = new StringBuilder();
		sb2.append("[");
		for(int i = 0; i < this.nod;i++) {
			sb2.append(z[i]);
			if(i < this.nod-1) {
				sb2.append(", ");
			}
		}
		sb2.append("]");
		this.res = sb2.toString();
	 
	}
	
	public String getFinalString() {
		return this.res;
	}
	
	public String toString() {
		String s;
		
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0; i<this.seq1.length;i++) {
			sb.append(this.seq1[i]);
			if(i<this.seq1.length-1) {
				sb.append(", ");
			}
		}
		sb.append("]");
		String seqa = sb.toString();
		
		StringBuilder sb1 = new StringBuilder();
		sb1.append("[");
		for(int i = 0; i<this.seq2.length;i++) {
			sb1.append(this.seq2[i]);
			if(i<this.seq2.length-1) {
				sb1.append(", ");
			}
		}
		sb1.append("]");
		String seqb = sb1.toString();
		
			s = String.format("Projecting %s to %s results in: %s", seqa, seqb, this.res);
		
		return s;
	}
	
}
