package model;

public class SumsOfPrefixes extends SeqOperation {

	protected int[] seq;
	protected String strA;
	
	public SumsOfPrefixes(int[] seq) {
		this.seq = seq;
		this.sum(seq);
		this.strA = "";
	}
	
	public String sum(int[] seq) {
		StringBuilder sb = new StringBuilder();
		sb.append("[0, ");
		for(int i = 0; i < seq.length; i++) {
			
			if(i == 0) {
				sb.append(seq[0]);
			}else {
				int sum = 0;
				for(int j = i; j >= 0; j--) {
					sum = sum + seq[j];
				}
				sb.append(sum);
			}
			
			if(i < seq.length-1) {
				sb.append(", ");
			}
			
		}
		
		sb.append("]");
		
		return sb.toString();
	}
	
	public String getFinString() {
		return this.sum(this.seq);
	}
	
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0; i<this.seq.length;i++) {
			sb.append(this.seq[i]);
			if(i<this.seq.length-1) {
				sb.append(", ");
			}
		}
		sb.append("]");
		String seqa = sb.toString();
		
		String s = String.format("Sums of prefixes of %s is: %s", seqa, this.sum(this.seq));
		return s;
	}
}
