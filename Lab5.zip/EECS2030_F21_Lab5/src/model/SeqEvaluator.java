package model;

public abstract class SeqEvaluator {

	protected int MAX_OP;
	protected String[] seq;
	protected int nos;
	
	protected int noe;
	
	public SeqEvaluator(int MAX_OP) {
		this.MAX_OP = MAX_OP;
		this.seq = new String[MAX_OP];
		
	}
	
	public abstract void addOperation(String str, int[] seqa, int[] seqb) throws IllegalOperationException;

}
