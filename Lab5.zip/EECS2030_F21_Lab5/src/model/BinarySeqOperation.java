package model;

public abstract class BinarySeqOperation extends SeqOperation {

}
