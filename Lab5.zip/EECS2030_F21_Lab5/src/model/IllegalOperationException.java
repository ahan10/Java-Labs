package model;

public class IllegalOperationException extends Exception {

}
