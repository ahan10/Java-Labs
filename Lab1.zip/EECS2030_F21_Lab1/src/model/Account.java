package model;

public class Account {
	public String personName;
	public AppStore storeName;
	public App[] downloads;
	public String[] nameDownloads;
	public String status;
	public final int MAX_SIZE = 50;
	public int counter;
	
	public Account(String personName, AppStore storeName) {
		this.personName = personName;
		this.storeName = storeName;
		this.downloads = new App[MAX_SIZE];
		this.nameDownloads = new String[MAX_SIZE];
		this.counter = 0;
		this.status = "An account linked to the " + this.storeName.getBranch() + " store is created for " + this.personName +".";
	}
	public String[] getNamesOfDownloadedApps() {
		String[] temp = new String[this.counter];
		for(int i = 0; i < this.counter; i++) {
			temp[i] = this.downloads[i].getName();
		}
		return temp;
	}
	
	public App[] getObjectsOfDownloadedApps() {
		App[] temp = new App[this.counter];
		for(int i = 0; i < this.counter; i++) {
			temp[i] = this.downloads[i];
		}
		return temp;
	}
	
	public void uninstall(String appName) {
		boolean b = false;
		int var = -1;
		for(int i = 0; i < this.counter; i++) {
			if(this.downloads[i].getName().equals(appName)) {
				var = i;
				b = true;
			}
		}
		if(b == true) {
			for(int i = var; i < this.counter;i++){
				this.downloads[i] = this.downloads[i+1];
				this.status = appName.toString() + " is successfully uninstalled for " + this.personName+".";
				this.counter--;
			}
		}else {
			this.status = "Error: " + appName.toString() + " has not been downloaded for " + this.personName+".";
		}
	}
	
	public void submitRating(String appName, int rating) {
		boolean b = false;
		int var = -1;
		for(int i = 0; i < this.counter; i++) {
			if(this.downloads[i].getName().equals(appName)) {
				b = true;
				var = i;
			}
		}
		if(b == false) {
			this.status = "Error: " + appName.toString() + " is not a downloaded app for " + this.personName+".";
		}else {
			this.downloads[var].submitRating(rating);
			this.status = "Rating score " + rating + " of " + this.personName + " is successfully submitted for " + appName+".";
		}
	}
	
	public void switchStore(AppStore appStore) {
		this.storeName = appStore;
		this.status = "Account for " + this.personName +  " is now linked to the " + this.storeName.getBranch() + " store.";
	}
	
	public void download(String appName) {
		boolean b = false;
		for(int i = 0; i < this.counter; i++) {
			if(this.downloads[i].getName().equals(appName)) {
				b = true;
			}
		}
		if(b == false) {
			this.downloads[this.counter] = this.storeName.getApp(appName);
			this.counter++;
			this.status = appName.toString() + " is successfully downloaded for " + this.personName+".";
		}else {
			this.status = "Error: " + appName.toString() + " has already been downloaded for " + this.personName+".";
		}
	}
	
	public String toString() {
		return this.status;
	}
	
}
