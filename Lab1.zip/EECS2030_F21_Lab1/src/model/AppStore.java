package model;

public class AppStore {
	private String country;
	private App[] apps;
	private int maxApps;
	private int counter;
	
	public AppStore(String country, int maxApps) {
		this.country = country;
		this.maxApps = maxApps;
		this.apps = new App[this.maxApps];
		this.counter =0;
		}
	
	public String getBranch() {
		return this.country;
	}

	public App getApp(String app) {
		int var = -1;
		for(int i = 0; i < this.counter; i++) {
			if(apps[i].getName().equals(app)) {
			var = i;
			}
		}
		if(var < 0) {
			return null;
		}else {
			return this.apps[var];
		}
	}

	public String[] getStableApps(int input) {
		App[] temp = new App[this.counter];
		int count = 0;
		for(int i = 0; i < this.counter; i++) {
			if(apps[i].getUpdate() >= input) {
				temp[count] = apps[i];
				count++;
			}
		}
		App[] tempArr = new App[count];
		for (int i = 0; i<count; i++){
			tempArr[i] = temp[i];
		}
		String[] temp2 = new String[count];
		for(int i = 0; i < count;i++) {
			String S = String.format("%s (%d versions; Current Version: %s)", tempArr[i].getName(), tempArr[i].getUpdate(), tempArr[i].getWhatIsNew());
			temp2[i] = S;
		}
		return temp2;
	}

	public void addApp(App app1) {
		this.apps[this.counter] = app1;
		this.counter++;
	}
	
	
}
