package model;

public class App {
	private String appName;
	private int nor;
	private Log[] history;
	private int[] ratings;
	public final int MAX_CAP = 20; 
	public final int MAX_RATE = 15;
	public int counter;
	private double average;
	public int count;
	private double sum;
	private int count1 = 0;
	private int count2 = 0;
	private int count3 = 0;
	private int count4 = 0;
	private int count5 = 0;

	public App(String appName, int nor) {
		this.appName = appName;
		this.nor = nor;
		this.history = new Log[MAX_CAP];
		this.ratings = new int[this.nor];
		this.counter = 0;
		this.average = 0.0;
		this.count = 0;
		this.sum = 0.0;
		this.count1 = 0;
		this.count2 = 0;
		this.count3 = 0;
		this.count4 = 0;
		this.count5 = 0;
	}

	public String getName() {
		return this.appName;
	}

	public void releaseUpdate(String update) {
		Log temp = new Log(update);
		this.history[this.counter] = temp;
		this.counter++;
	}

	public Log[] getUpdateHistory() {
		Log[] temp = new Log[this.counter];
		for(int i = 0; i < this.counter; i++) {
			temp[i] = this.history[i];
		}
		return temp;
	}

	public String getWhatIsNew() {
		if(this.counter == 0) {
			return "n/a";
		}else {
			return this.history[this.counter-1].toString();
		}
	}
	
	public int getUpdate(){
		return this.counter;
	}
	
	public void submitRating(int review) {
		this.sum = this.sum + review;
		this.count++;
		switch(review){
		case 1:
			this.count1++;
			break;
		case 2:
			this.count2++;
			break;
		case 3:
			this.count3++;
			break;
		case 4:
			this.count4++;
			break;
		case 5:
			this.count5++;
			break;
		}
		this.ratings[0] = this.count1;
		this.ratings[1] = this.count2;
		this.ratings[2] = this.count3;
		this.ratings[3] = this.count4;
		this.ratings[4] = this.count5;

		this.average =  this.sum/(double)this.count; 
	}

	public Log getVersionInfo(String version) {
		int var = -1;
		for(int i = 0; i < this.counter; i++) {
		if(this.history[i].getVersion().equals(version)) {
			var = i;
			}
		}
		if(var < 0) {
			return null;
		}else {
			return this.history[var];
		}
	}

	public String getRatingReport() {
		if(this.count == 0) {
			return "No ratings submitted so far!";
		}else {
			String s = String.format("Average of %d ratings: %.1f (Score 5: %d, Score 4: %d, Score 3: %d, Score 2: %d, Score 1: %d)",this.count ,this.average, this.ratings[4], this.ratings[3], this.ratings[2], this.ratings[1], this.ratings[0]);
			return s;
		}	
	}

	public String toString() {
		if(this.counter == 0) {
			return this.appName + " (Current Version: n/a; Average Rating: n/a)";
		}else {
			String str = String.format("%s (Current Version: %s; Average Rating: %.1f)", this.appName, this.getWhatIsNew(), this.average);
			return str;
		}
	}
}
