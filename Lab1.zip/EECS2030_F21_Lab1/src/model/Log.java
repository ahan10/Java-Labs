package model;

public class Log {
	private String version;
	private String[] fixes;
	private int numberOfFixes;
	private final int MAX_CAPACITY = 10;
	private String stringOfFixes;
	
	public Log(String version) {
		this.version = version;
		this.fixes = new String[MAX_CAPACITY];
	}
	
	public String getVersion() {
		return this.version;
	}

	public int getNumberOfFixes() {
		return numberOfFixes;
	}
	
	public void addFix(String fix) {
		this.fixes[this.numberOfFixes] = fix;
		this.numberOfFixes++;
	}
	
	public String getFixes() {
		if(this.numberOfFixes == 0) {
			return "[]";
		}
		else {
			String[] es = new String[this.numberOfFixes];
			for(int i = 0; i < this.numberOfFixes; i++) {
				es[i] = this.fixes[i];
			}
			StringBuilder sb = new StringBuilder();
			sb.append("[");
				for(int i = 0; i < numberOfFixes; i++) {
					sb.append(es[i]);
					if(i < numberOfFixes-1) {
						sb.append(", ");
				}
			}
			sb.append("]");
			this.stringOfFixes = sb.toString();
			return this.stringOfFixes;
		}
	}
	
	public String toString() {
		if(this.numberOfFixes == 0) {
			return "Version " + this.version + " contains " + numberOfFixes + " fixes " + "[]";
		}
		else {
			return "Version " + this.version + " contains " + numberOfFixes + " fixes " + this.getFixes();
		}
	}

	
}
