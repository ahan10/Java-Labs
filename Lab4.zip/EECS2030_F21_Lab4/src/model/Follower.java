package model;

public class Follower {

	protected String subName;
	private String monitorName;
	protected int count;
	protected Channel[] followedChannels;
	protected int followCount;
	protected String[] releasedVideos;
	protected int nof;
	protected int flag;
	protected String vidName;
	protected int time;
	protected int maxChannel;
	protected int views;
	protected String[] watched;
	protected int[] timeaerr;
	protected boolean watch;

	public Follower(String subName, int maxChannel, int maxRec) {
		this.subName = subName;
		this.followCount = 0;
		this.followedChannels = new Channel[maxChannel];
		this.count = 1;
		this.releasedVideos = new String[maxRec];
		this.flag = 0;
		this.nof = 0;
		this.watched = new String[100];
		this.timeaerr = new int[100];
	}

	public Follower(String monitorName, int maxChannel) {
		this.monitorName = monitorName;
		this.count = 2;
		this.followCount = 0;
		this.maxChannel = maxChannel;
		this.views = 0;
		this.followedChannels = new Channel[maxChannel];
		this.watched = new String[100];
		this.timeaerr = new int[100];
	}

	public void videoRelesedAfterFollow(String vid) {
		this.releasedVideos[this.nof] = vid;
		this.nof++;
		this.flag = 1;
	}

	public String getSubName() {
		return this.subName;
	}

	public int getFollowCount() {
		return this.followCount;
	}

	public int getCount() {
		return this.count;
	}

	public String getMonitorName() {
		return this.monitorName;
	}

	public void followChannel(Channel channel) {
		this.followedChannels[this.followCount] = channel;
		this.followCount++;
	}

	public void unfollowChannel(Channel channel) {
		Channel[] fs = new Channel[this.followCount-1];

		for(int i = 0, j = 0; i < this.followCount; i++) {
			if(this.followedChannels[i] != channel) {
				fs[j] = this.followedChannels[i];
				j++;
			}
		}

		this.followCount--;
		for(int i = 0; i < this.followCount; i++) {
			this.followedChannels[i] = fs[i];
		}

	}

	public String toString() {
		String s;

		if(this.followCount == 0) {
			s= String.format("Subscriber %s follows no channels and has no recommended videos.", this.subName);
		}else 
			if(this.flag == 1){
				StringBuilder sb2 = new StringBuilder();
				sb2.append("<");
				for(int i = 0; i< this.nof; i++) {
					sb2.append(this.releasedVideos[i]);
					if(i<this.nof-1) {
						sb2.append(", ");
					}

				}
				sb2.append(">");
				String reccomend = sb2.toString();

				StringBuilder sb1 = new StringBuilder();
				sb1.append("[");
				for(int i = 0; i< this.followCount; i++) {
					sb1.append(this.followedChannels[i].getChannelName());
					if(i<this.followCount-1) {
						sb1.append(", ");
					}
				}
				sb1.append("]");
				String video = sb1.toString();
				s= String.format("Subscriber %s follows %s and is recommended %s.", this.subName, video, reccomend);
			}else {
				StringBuilder sb1 = new StringBuilder();
				sb1.append("[");
				for(int i = 0; i< this.followCount; i++) {
					sb1.append(this.followedChannels[i].getChannelName());
					if(i<this.followCount-1) {
						sb1.append(", ");
					}
				}
				sb1.append("]");
				String video = sb1.toString();
				s= String.format("Subscriber %s follows %s and has no recommended videos.", this.subName, video);
			}
		return s;
	}
}
