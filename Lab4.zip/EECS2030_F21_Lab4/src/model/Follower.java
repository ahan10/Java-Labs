package model;

public class Follower {
	
	protected String subName;
	private String monitorName;
	private int maxChannel;
	private int maxRec;
	private int count;
	private String[] followedChannels;
	private int followCount;
	
	
	public Follower(String subName, int maxChannel, int maxRec) {
		this.subName = subName;
		this.maxChannel = maxChannel;
		this.maxRec = maxRec;
		this.followCount = 0;
		this.followedChannels = new String[maxChannel];
		this.count = 1;
	}
	
	public Follower(String monitorName, int maxChannel) {
		this.monitorName = monitorName;
		this.maxChannel = maxChannel;
		this.count =2;
		this.followCount = 0;
		this.followedChannels = new String[maxChannel];
	}
	
	public String getSubName() {
		return this.subName;
	}
	
	public int getFollowCount() {
		return this.followCount;
	}
	
	public int getCount() {
		return this.count;
	}
	
	public String getMonitorName() {
		return this.monitorName;
	}
	
	public void followChannel(String channel) {
		this.followedChannels[this.followCount] = channel;
		this.followCount++;
	}
	
	public void unfollowChannel(String channel) {
		String[] fs = new String[this.followCount-1];
		int k = 0;
		for(int i = 0; i< this.followCount; i++) {
			if(this.followedChannels[i] == channel) {
				i = k;
			}
		}
		for(int i = 0, j = 0; i<this.followCount; i++) {
			if(i == k) {
				continue;
			}
			fs[j] = this.followedChannels[i];
			j++;
		}
		this.followCount--;
		this.followedChannels = fs;
		
	}
	
	public String toString() {
		String s;
		if(this.count == 1) {
			if(this.followCount == 0) {
				s= String.format("Subscriber %s follows no channels and has no recommended videos.", this.subName);
			}else {
				StringBuilder sb = new StringBuilder();
				sb.append("[");
				for(int i = 0; i< this.followCount; i++) {
					sb.append(this.followedChannels[i]);
					if(i<this.followCount-1) {
						sb.append(", ");
					}
				}
				sb.append("]");
				
				String video = sb.toString();
				s= String.format("Subscriber %s follows %s and has no recommended videos.", this.subName, video);
			}
	
		}else {
			if(this.followCount == 0) {
				s = String.format("Monitor %s follows no channels.", this.monitorName);
			}else {
				StringBuilder sb = new StringBuilder();
				sb.append("[");
				for(int i = 0; i< this.followCount; i++) {
					sb.append(this.followedChannels[i]);
					if(i<this.followCount-1) {
						sb.append(", ");
					}
				}
				sb.append("]");
				
				String video = sb.toString();
				s= String.format("Monitor %s follows %s.", this.monitorName, video);
			}
			
		}
		return s;
	}
	
}

