package model;

public class Monitor extends Follower {
	public Monitor(String monitorName, int maxChannel) {
		super(monitorName, maxChannel);
	}
}
