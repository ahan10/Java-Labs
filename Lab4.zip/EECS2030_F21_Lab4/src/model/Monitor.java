package model;

public class Monitor extends Follower {
	
	protected String channelName;
	protected String monitorName;
	protected int k;
	
	public Monitor(String monitorName, int maxChannel) {
		super(monitorName, maxChannel);
		this.channelName = monitorName;
		this.k = 0;
	}
	
	protected void setWatch(String video, int time) {
		this.watched[this.k] = video;
		this.timeaerr[this.k] = time;
		this.k++;
		this.views++;
		watch = true;
	}

	protected double avgTime() {
		double avg = 0;
		double sum = 0;
		for (int i = 0; i< this.timeaerr.length; i++) {
			sum = sum + this.timeaerr[i];
		}
		avg = sum / this.views;
		return avg;
	}

	protected int maxTime() {
		int max = this.timeaerr[0];
		for (int i = 0; i< this.timeaerr.length; i++) {
			if(this.timeaerr[i] > max)
				max = this.timeaerr[i];
		}
		return max;
	}
	
	public String toString() {
		String s;
		if(watch) {
			StringBuilder sb1 = new StringBuilder();
			sb1.append("[");
			//String a = "";
			for(int i = 0; i< this.followCount; i++) {
				sb1.append(this.followedChannels[i].getChannelName());
				if(this.followedChannels[i].getViews() >0) {
					sb1.append(" {#views: " + this.views);
					sb1.append(", max watch time: "+ this.maxTime());
					String avg = String.format("%.2f",this.avgTime());
					sb1.append(", avg watch time: "+ avg);
					sb1.append("}");
				}
				if(i<this.followCount-1) {
					sb1.append(", ");
				}
			}
			sb1.append("]");
			
			String video = sb1.toString();
			s = String.format("Monitor %s follows %s.", this.channelName, video);
		}
		else if(this.followCount == 0) {
			s = String.format("Monitor %s follows no channels.", this.channelName);
		}else {
	StringBuilder sb = new StringBuilder();
	sb.append("[");
	for(int i = 0; i< this.followCount; i++) {
		sb.append(this.followedChannels[i].getChannelName());
		if(i<this.followCount-1) {
			sb.append(", ");
		}
	}
	sb.append("]");
	
	String video = sb.toString();
	s= String.format("Monitor %s follows %s.", this.channelName, video);
		}
		 
		return s;
	}

}
