package model;

public class Subscriber extends Follower {

	protected int time;
	protected String vidName;
	protected String channelName;
	protected String[] videos;
	protected int noov;
	
	public Subscriber(String subName, int maxChannel, int maxRec) {
		super(subName, maxChannel, maxRec);
		this.videos = new String[100];
		this.noov = 0;
	}
	
	public void watch(String vidName, int time) {
		for(int i = 0; i<this.followCount; i++) {
			if(this.followedChannels[i].getVideos().contains(vidName) && time>0) {
				this.followedChannels[i].addWatchedVideo(vidName, time);
				this.views++;
				break;
			}
		}
		
	}
	

	
}
