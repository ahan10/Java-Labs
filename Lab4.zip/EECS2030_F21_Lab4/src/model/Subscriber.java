package model;

public class Subscriber extends Follower {
	public Subscriber(String subName, int maxChannel, int maxRec) {
		super(subName, maxChannel, maxRec);
		
	}
}
