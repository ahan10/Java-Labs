package model;

public class Channel {

	private String channelName;
	private int followCount;
	private int videoCount;
	private String[] videos;
	private Follower[] follower;
	protected int nov;
	protected int views;
	
	public Channel(String channelName, int maxFollower, int maxVideos) {
		this.channelName = channelName;
		this.followCount = 0;
		this.videoCount = 0;
		this.videos = new String[maxVideos];
		this.follower = new Follower[maxFollower];
		this.nov = 0;
		this.views = 0;
	}
	
	public void releaseANewVideo(String video) {
		this.videos[this.videoCount] = video;
		this.videoCount++;
		if(this.followCount != 0) {
			for(int i = 0; i <this.followCount; i++) {
				if(this.follower[i].getCount() == 1)
					this.follower[i].videoRelesedAfterFollow(video);
			}
		}
	}
	
	protected void addWatchedVideo(String video, int time) {
		for(int i = 0; i<this.followCount; i++) {
			if(this.follower[i] instanceof Monitor) {
				Monitor k = (Monitor) this.follower[i];
				k.setWatch(video, time);
				this.views++;
			}
		}
		this.nov++;
	}
	
	protected int getViews() {
		return this.views;
	}
	
	public void follow(Follower f) {
		this.follower[this.followCount] = f;
		this.follower[this.followCount].followChannel(this);
		this.followCount++;
	}

	public String getChannelName() {
		return this.channelName;
	}
	
	public void unfollow(Follower f) {
		boolean b = false;
		for(int i = 0; i < this.followCount; i++) {
			if(this.follower[i] == f) {
				b = true;
				break;
			}
		}
		if(b) {
			Follower[] fs = new Follower[this.followCount-1];
			int k = 0;
			for(int i = 0, j = 0; i < this.followCount; i++) {
				if(this.follower[i] != f) {
					fs[j] = this.follower[i];
					j++;
				}else {
					k = i;
				}
			}
			this.follower[k].unfollowChannel(this);
			this.followCount--;
			for(int i = 0; i<this.followCount; i++) {
				this.follower[i] = fs[i];
			}
		}		
	}
	
	public int getVidCount() {
		return this.videoCount;
	}
	
	public String getVideos() {
		String videostr ="";
		for(int i = 0 ; i<this.videoCount; i++) {
			videostr = videostr + this.videos[i].toString(); 
			videostr = videostr + " ";
		}
		return videostr;
	}
	
	public String toString() {
		String s;
		if(this.videoCount == 0 && this.followCount == 0) {
			s = String.format("%s released no videos and has no followers.", this.channelName);
		}else if(this.videoCount == 0 && this.followCount != 0){
			StringBuilder sb = new StringBuilder();
			sb.append("[");
			for(int i = 0; i < this.followCount; i++) {
				if(this.follower[i].getCount() == 1) {
					sb.append("Subscriber " + this.follower[i].getSubName().toString());
				}else {
					sb.append("Monitor " + this.follower[i].getMonitorName().toString());
				}
				if(i<this.followCount-1) {
					sb.append(", ");
				}
			}
			sb.append("]");
			String a = sb.toString();
			s = String.format("%s released no videos and is followed by %s.", this.channelName, a);
		}else {
			StringBuilder sb = new StringBuilder();
			sb.append("<");
			for(int i = 0; i< this.videoCount; i++) {
				sb.append(this.videos[i]);
				if(i<this.videoCount-1) {
					sb.append(", ");
				}
			}
			sb.append(">");
			
			String video = sb.toString();
			
			if(this.videoCount != 0 && this.followCount == 0) {
				s = String.format("%s released %s and has no followers.", this.channelName, video);
			}else {
				StringBuilder sb1 = new StringBuilder();
				sb1.append("[");
				for(int i = 0; i < this.followCount; i++) {
					if(this.follower[i].getCount() == 1) {
						sb1.append("Subscriber " + this.follower[i].getSubName().toString());
					}else {
						sb1.append("Monitor " + this.follower[i].getMonitorName().toString());
					}
					if(i<this.followCount-1) {
						sb1.append(", ");
					}
				}
				sb1.append("]");
				String a = sb1.toString();
				s = String.format("%s released %s and is followed by %s.", this.channelName, video, a);
				//s = String.format("%s released %s and has %d followers.", this.channelName, video, this.followCount);
			}
		}
		
		return s;
	}

}
