package model;

public class Channel {

	private String channelName;
	private int followCount;
	private int videoCount;
	private String[] videos;
	private Follower[] follower;
	
	public Channel(String channelName, int maxFollower, int maxVideos) {
		this.channelName = channelName;
		this.followCount = 0;
		this.videoCount = 0;
		this.videos = new String[maxVideos];
		this.follower = new Follower[maxFollower];
	}
	
	public void releaseANewVideo(String video) {
		this.videos[this.videoCount] = video;
		this.videoCount++;
	}
	
	public String toString() {
		String s;
		if(this.videoCount == 0 && this.followCount == 0) {
			s = String.format("%s released no videos and has no followers.", this.channelName);
		}else if(this.videoCount == 0 && this.followCount != 0){
			StringBuilder sb = new StringBuilder();
			sb.append("[");
			for(int i = 0; i < this.followCount; i++) {
				if(this.follower[i].getCount() == 1) {
					sb.append("Subscriber " + this.follower[i].getSubName().toString());
				}else {
					sb.append("Monitor " + this.follower[i].getMonitorName().toString());
				}
				if(i<this.followCount-1) {
					sb.append(", ");
				}
			}
			sb.append("]");
			String a = sb.toString();
			s = String.format("%s released no videos and is followed by %s.", this.channelName, a);
		}else {
			StringBuilder sb = new StringBuilder();
			sb.append("<");
			for(int i = 0; i< this.videoCount; i++) {
				sb.append(this.videos[i]);
				if(i<this.videoCount-1) {
					sb.append(", ");
				}
			}
			sb.append(">");
			
			String video = sb.toString();
			
			if(this.videoCount != 0 && this.followCount == 0) {
				s = String.format("%s released %s and has no followers.", this.channelName, video);
			}else {
				StringBuilder sb1 = new StringBuilder();
				sb1.append("[");
				for(int i = 0; i < this.followCount; i++) {
					if(this.follower[i].getCount() == 1) {
						sb1.append("Subscriber " + this.follower[i].getSubName().toString());
					}else {
						sb1.append("Monitor " + this.follower[i].getMonitorName().toString());
					}
					if(i<this.followCount-1) {
						sb1.append(", ");
					}
				}
				sb1.append("]");
				String a = sb1.toString();
				s = String.format("%s released %s and is followed by %s.", this.channelName, video, a);
			}
		}
		
		return s;
	}

	public void follow(Follower f) {
		this.follower[this.followCount] = f;
		this.follower[this.followCount].followChannel(this.channelName);
		this.followCount++;
	}

	public void unfollow(Follower f) {
		
		Follower[] fs = new Follower[this.followCount-1];
		int k = 0;
		for(int i = 0; i< this.followCount; i++) {
			if(this.follower[i] == f) {
				i = k;
			}
		}
		this.follower[k].unfollowChannel(this.channelName);	
		for(int i = 0, j = 0; i<this.followCount; i++) {
			if(i == k) {
				continue;
			}
			fs[j] = this.follower[i];
			j++;
		}
		this.follower = fs;
		this.followCount--;
		this.follower[this.followCount-1].unfollowChannel(this.channelName);	
	}

}