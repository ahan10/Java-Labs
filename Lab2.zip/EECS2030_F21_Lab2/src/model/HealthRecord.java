package model;

public class HealthRecord {

	private String patientName;
	private int limit;
	private int count;
	private String siteName1;
	private String[] siteName;
	private String[] date;
	private Vaccine[] vac;
	private int counter;
	private int flagVal;

	public HealthRecord(String patientName, int limit) {
		this.patientName = patientName;
		this.limit = limit;
		this.count = 0;
		this.siteName = new String[limit];
		this.date = new String[limit];
		this.vac = new Vaccine[limit];
		this.counter = 0;
		this.flagVal = 0;
	}

	public void addRecord(Vaccine v, String site, String date) {
		for(int i = this.count; i<= this.count; i++) {
			this.vac[i] = v;
			this.siteName[i] = site;
			this.date[i] = date;
		}
		this.count++;
	}

	public void setCount(int counter2) {
		this.counter = counter2;
	}

	public int getCounter() {
		return this.counter;
	}

	public void setSiteName(String siteName2) {
		this.siteName1 = siteName2;
	}

	public void setFlagValue(int value) {
		this.flagVal = value;
	}

	public String getPatientName() {
		return this.patientName;
	}

	public String getVaccinationReceipt() {
		String s;
		if(this.count == 0) {
			s = String.format("%s has not yet received any doses.", this.patientName);
		}else {	
			StringBuilder sb = new StringBuilder();
			sb.append("Number of doses " + this.patientName + " has received: " + this.count + " [");
			for(int i = 0; i < this.count; i++) {
				sb.append(this.vac[i].toString() + " in " + this.siteName[i] + " on " + this.date[i]);
				if(i < this.count-1) {
					sb.append("; ");
				}
			}
			sb.append("]");
			s = sb.toString();
		}
		return s;
	}

	public String getAppointmentStatus() {
		String s;
		if(this.flagVal == -1) {
			s = "Last vaccination appointment for " + this.patientName + " with " + this.siteName1.toString() +" failed";

		}else if(this.counter == 0){
			s = String.format("No vaccination appointment for %s yet", this.patientName);
		}else {
			s = String.format("Last vaccination appointment for %s with %s succeeded", this.patientName, this.siteName1.toString());
		}
		return s;
	}

}
