package model; 

public class VaccinationSite {

	private String siteName;
	private int limit;
	private Vaccine[] vac;
	private HealthRecord[] app;
	private int count;
	private int counter;
	private int[] supply;
	private int suppSum;
	private int counter1;
	private int flagVal;
	private int glag;
	
	public VaccinationSite(String siteName, int noOfDosesAv) {
		this.siteName = siteName;
		this.limit = noOfDosesAv;
		this.vac = new Vaccine[noOfDosesAv];
		this.count = 0;
		this.counter = 0;
		this.counter1 = 0;
		this.app = new HealthRecord[200];
		this.supply = new int[noOfDosesAv];
		this.suppSum = 0;
		this.flagVal = 0;
		this.glag = 0;
	}

	public int getNumberOfAvailableDoses() {
		return this.suppSum;
	}

	public int getNumberOfAvailableDoses(String codeName) {
		int k = -1;
		for(int j = 0; j < this.count; j++) {
			if(this.vac[j].getCodeName().equals(codeName)) {
				k = j;
				break;
			}
		}
		if(k == -1) {
			return 0;
		}else {
			return this.supply[k];
		}
		
	}

	public void addDistribution(Vaccine v1, int supp) throws TooMuchDistributionException, UnrecognizedVaccineCodeNameException {
		int glag = 0;
		int flag = 0;
		int k = 0;
		this.suppSum = this.suppSum + supp;
		if(!( (v1.getCodeName().equals("mRNA-1273")) || (v1.getCodeName().equals("BNT162b2")) || (v1.getCodeName().equals("Ad26.COV2.S")) || (v1.getCodeName().equals("AZD1222")))) {
			throw new UnrecognizedVaccineCodeNameException();
		}	
		else if(this.suppSum > this.limit) {
			throw new TooMuchDistributionException();
		}else {
			for(int i = this.count; i <= this.count; i++) {
				if(i == 0) {
					this.vac[i] = v1;
					this.supply[i] = supp;
					glag = 1;
					break;
				}else {
					for(int j = 0; j < this.vac.length; j++) {
						if(this.vac[j] == v1) {
							flag = 1;
							k = j;
							break;
						}
					}
					if(flag == 0) {
						this.vac[i] = v1;
						this.supply[i] = supp;
						glag = 1;
						break;
					}else {
						this.supply[k] = this.supply[k] + supp;
					}
				}
			}
			if(glag == 1)
				this.count++;
		}
	}

	public void bookAppointment(HealthRecord h1) throws InsufficientVaccineDosesException {
		int sum = this.suppSum;
		if(this.counter != sum) {
			for(int i = this.counter; i<= this.counter; i++) {
				this.app[i] = h1;
			}
			if(this.glag == -1) {
				this.flagVal = this.counter - 1;
			}
			this.counter++;
			h1.setCount(this.counter);
			h1.setSiteName(this.siteName);
			
		}else {
			this.counter1 = -1;
			h1.setFlagValue(this.counter1);
			h1.setSiteName(this.siteName);
			throw new InsufficientVaccineDosesException(); 
		}
	}

	public void administer(String date) {
		int k = 0;
		int i = 0;
		int p = 0;
		if(this.glag == -1) {
			p = k;
			i = this.counter - this.suppSum;
		}
		this.suppSum = this.suppSum - this.counter + this.flagVal;
		for(int j = 0; j <= this.counter; j++ ) {
			if(this.supply[k] != 0) {
				this.supply[k] = this.supply[k] - 1;
				this.app[i].addRecord(this.vac[k], this.siteName, date);
				i++;
			}else {
				k++;
			}
			this.glag = -1;
			p = k;
		}
	}
	
	public String toString() {
		String s ="";
		StringBuilder sb = new StringBuilder();
		sb.append(this.siteName + " has " + this.suppSum + " available doses: <");
		for(int i = 0; i < this.count; i++) {
			sb.append(this.supply[i] + " doses of " + this.vac[i].getName().toString());
			if(i < this.count-1) {
				sb.append(", ");
			}
		}
		sb.append(">");
		s = sb.toString();

		return s;
	}

}
