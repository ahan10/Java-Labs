package model;

public class Vaccine {

	private String codeName;
	private String type;
	private String vacName;
	
	public Vaccine(String codeName, String type, String vacName) {
		this.codeName = codeName;
		this.type = type;
		this.vacName = vacName;
	}
	
	public String getName() {
		return this.vacName;
	}
	
	public String getCodeName() {
		return this.codeName;
	}
	
	public String toString() {
		String s;
		if((this.codeName.equals("mRNA-1273") || this.codeName.equals("BNT162b2") || this.codeName.equals("Ad26.COV2.S") || this.codeName.equals("AZD1222")))
			 s = String.format("Recognized vaccine: %s (%s; %s)", this.getCodeName(), this.type, this.getName());
		else
			s = String.format("Unrecognized vaccine: %s (%s; %s)", this.codeName, this.type, this.vacName);
		return s;
	}
	
}
