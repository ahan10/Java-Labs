package model;

public class TooMuchDistributionException extends Exception {

}
