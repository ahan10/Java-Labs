package model;

public class VaccineDistribution{

	private int noOfDoses;
	private Vaccine vac;
	
	public VaccineDistribution(Vaccine v1, int noOfDoses) {
		this.vac = v1;
		this.noOfDoses = noOfDoses;
	}

	public String toString() {
		String s = String.format("%d doses of %s by %s", this.noOfDoses, this.vac.getCodeName().toString(), this.vac.getName().toString());
		return s;
	}
}
